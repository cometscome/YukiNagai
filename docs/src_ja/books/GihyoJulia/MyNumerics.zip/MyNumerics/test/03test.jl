using LinearAlgebra
const A03 = [9 2 1 1
    2 8 -2 3
    -1 -2 7 -2
    1 -1 4 6]
function test03_standard()
    e, v = eigen(A03)
    println("eigenvalue")
    display(e)
    println("\t")
    println("eigenvectors")
    display(v)
    println("\t")
end
test03_standard()
function test03_power()
    x0 = Float64[1, 2, 3, 4]
    e1, v1 = power_method(A03, x0)
    println("残差ノルム：", norm(A03 * v1 - e1 * v1))
    println("Maximum eigenvalue:")
    display(e1)
    println("eigenvector:")
    display(v1)
end
test03_power()
function test03_inverse_power()
    x0 = Float64[1, 2, 3, 4]
    e1, v1 = inverse_power_method(A03, x0)
    println("残差ノルム：", norm(A03 * v1 - e1 * v1))
    println("Minimum eigenvalue:")
    display(e1)
    println("eigenvector:")
    display(v1)
end
test03_inverse_power()
function test03_inverse_power_LU()
    x0 = Float64[1, 2, 3, 4]
    e1, v1 = inverse_power_method_LU(A03, x0)
    println("残差ノルム：", norm(A03 * v1 - e1 * v1))
end
test03_inverse_power_LU()
function test03_unitary()
    A = [1 2 3
        2 4 5
        3 5 6
    ]
    θ = atan(2 * 5 / (6 - 4)) / 2
    U = [1 0 0
        0 cos(θ) sin(θ)
        0 -sin(θ) cos(θ)
    ]
    display(U' * A * U)
end
test03_unitary()
function test03_make_U()
    A = [1 2 3
        2 4 5
        3 5 6
    ]
    p = 2
    q = 3
    U1 = make_U(A, p, q)
    A2 = U1' * A * U1
    display(A2)
end
test03_make_U()
function test03_Jacobi()
    A = [1 2 3
        2 4 5
        3 5 6
    ]
    Ai, U = eigen_Jacobi(A)
    display(U' * A * U)
    return
end
test03_Jacobi()
function test03_householder()
    A = rand(6, 6)
    A = A' * A
    display(A)

    α, β, u = householder(A)
    println("α = $α")
    println("β = $β")
    x = rand(6)
    Tx = householder_matmul(α, β, x) #三重対角行列をかける
    Rx = householder_backtransform(u, x)
    RTx = householder_backtransform(u, Tx) #RTx = RRARx= ARx
    println("RTx ", RTx)
    ARx = A * Rx
    println("ARx ", ARx)
    println(norm(RTx - ARx))

    return
end
test03_householder()

function test03_bisection()
    A = rand(6, 6)
    A = A' * A
    display(A)
    e, v = eigen(A)
    α, β, u = householder(A)
    λ = trigonal_matrix_bisection(α, β)
    for i = 1:length(e)
        println("i = $i $(e[i]) $(λ[end-i+1]) $(e[i]-λ[end-i+1])")
    end
    λ = trigonal_matrix_bisection(α, β, eps=1e-14)
    for i = 1:length(e)
        println("i = $i $(e[i]) $(λ[end-i+1]) $(e[i]-λ[end-i+1])")
    end
    return
end
test03_bisection()