using LinearAlgebra
const A = [4 1 2 3
    2 9 -2 1
    -1 -2 8 -2
    1 -2 -3 4
]
const b = [20, 16, 8, 17]

function test01_Jacobi()
    x0 = A \ b
    println(x0)

    x = hanpuku_Jacobi(A, b)
    println("Jacobi: 残差ノルム：", norm(A * x - b))
end
test01_Jacobi()
function test01_GaussSeidel()
    x0 = A \ b
    println(x0)

    x = hanpuku_GaussSeidel(A, b)
    println("GaussSeidel: 残差ノルム：", norm(A * x - b))
end
test01_GaussSeidel()
function test01_syokyo()
    i = 1
    Ap, bp = syokyo(A, b, i)
    display(Ap)
    println("\t")

    i = 2
    Ap, bp = syokyo(A, b, i)
    display(Ap)
    println("\t")
end
test01_syokyo()

function test01_syokyo_fast()
    N = 1000
    A = rand(N, N)
    b = rand(N)

    i = 1
    Ap1, bp1 = syokyo(A, b, i)
    Ap2, bp2 = syokyo_fast(A, b, i)
    println(sum(Ap1 .- Ap2))

    i = 2
    @time Ap1, bp1 = syokyo(A, b, i)
    @time Ap2, bp2 = syokyo_fast(A, b, i)
    println(sum(Ap1 .- Ap2))
    i = 3
    @time Ap1, bp1 = syokyo(A, b, i)
    @time Ap2, bp2 = syokyo_fast(A, b, i)
    println(sum(Ap1 .- Ap2))
end
test01_syokyo_fast()
#error("ee")

function test01_gauss()
    n, m = size(A)
    At = zeros(n, m)
    At .= A
    bt = zeros(m)
    bt .= b
    gauss!(At, bt)
    display(At)
    println("\t")
    display(bt)
end
test01_gauss()
function test01_LU()
    n, m = size(A)
    At = zeros(n, m)
    At .= A
    LU!(At)

    bt = zeros(m)
    bt .= b
    x = solve_withLU!(At, bt)
    println("LU: 残差ノルム：", norm(A * x - b))
end
test01_LU()
using Random
function test01_gradient_descent()
    N = 20
    Random.seed!(113)
    A = rand(N, N)
    A = A' * A #これでA'=Aとなる。
    b = rand(N)
    x = rand(N)
    eps = 1e-10
    gradient_descent!(A, b, x, eps)
    println("gradient_descent: 残差ノルム：", norm(A * x - b))
end
test01_gradient_descent()
function test01_conjugate_gradient()
    N = 20
    Random.seed!(113)
    A = rand(N, N)
    A = A' * A #これでA'=Aとなる。
    b = rand(N)
    x = rand(N)
    eps = 1e-10
    conjugate_gradient!(A, b, x, eps)
    println("conjugate_gradient: 残差ノルム：", norm(A * x - b))
end
test01_conjugate_gradient()

using LinearAlgebra
struct MyMatrix{T} <: AbstractMatrix{T}
    data::Vector{T}
end
Base.size(a::MyMatrix) = (length(a.data), length(a.data))
function Base.getindex(A::MyMatrix, i, j)
    if i == j
        return A.data[i]
    else
        return zero(A.data[1])
    end
end
function LinearAlgebra.mul!(y::AbstractVector, A::MyMatrix, x::AbstractVector)
    for i = 1:length(y)
        y[i] = A.data[i] * x[i]
    end
    return y
end
function LinearAlgebra.mul!(y::AbstractVector, A::MyMatrix, x::AbstractVector, α::Number, β::Number)
    for i = 1:length(y)
        y[i] = α * A.data[i] * x[i] + β * y[i]
    end
    return y
end

function test01_conjugate_gradient_diagonal()
    N = 20
    Random.seed!(113)
    A = MyMatrix(rand(N))
    b = rand(N)
    x = rand(N)
    eps = 1e-10
    conjugate_gradient!(A, b, x, eps)
    println("conjugate_gradient: 残差ノルム：", norm(A * x - b))
end
test01_conjugate_gradient_diagonal()