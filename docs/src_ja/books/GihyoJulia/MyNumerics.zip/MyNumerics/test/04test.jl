function test04_daikeikubun()
    f(x) = 2 * x^2 + x + cos(x)
    F(x) = 2 * x^3 / 3 + x^2 / 2 + sin(x)
    a = 0
    b = 1
    Iexact = F(b) - F(a)
    I = kubun(f, a, b, N=1000)
    I2 = daikei(f, a, b, N=1000)
    sa = abs(Iexact - I) / abs(Iexact)
    sa2 = abs(Iexact - I2) / abs(Iexact)
    println("I: $I I2: $I2 Iexact: $Iexact ")
    println("誤差：　区分求積法 ", sa, " 台形公式: ", sa2)
end
test04_daikeikubun()
function test04_daikeisimpson()
    f(x) = 2 * x^2 + x + cos(x)
    F(x) = 2 * x^3 / 3 + x^2 / 2 + sin(x)
    a = 0
    b = 1
    Iexact = F(b) - F(a)
    I2 = daikei(f, a, b, N=1000)
    I3 = simpson(f, a, b, N=1000)
    sa2 = abs(Iexact - I2) / abs(Iexact)
    sa3 = abs(Iexact - I3) / abs(Iexact)
    println("I2: $I2 I3: $I3 Iexact: $Iexact ")
    println("誤差：　台形公式 ", sa2, " シンプソンの公式: ", sa3)
end
test04_daikeisimpson()
function test04_legendre_zero()
    for n = 1:10
        xks = functionzeros(n)
        Pnx = legendre_polynomial.(xks, n)
        println(Pnx)
    end
end
test04_legendre_zero()

function test04_legendreGauss()
    f(x) = 2 * x^2 + x + cos(x)
    F(x) = 2 * x^3 / 3 + x^2 / 2 + sin(x)
    a = 0
    b = 1
    Iexact = F(b) - F(a)
    N = 10
    I3 = simpson(f, a, b, N=N)
    sa3 = abs(Iexact - I3) / abs(Iexact)

    lzeros = functionzeros(N)
    I4 = legendre_Gauss(f, a, b, lzeros; N=N)
    sa4 = abs(Iexact - I4) / abs(Iexact)
    println("I3: $I3 I4: $I4 Iexact: $Iexact ")
    println("誤差：　シンプソン: ", sa3, " ルジャンドルガウス: ", sa4)
end
test04_legendreGauss()
using Plots
using LaTeXStrings
function plot_revolution()
    N = 100
    θ = range(0, 2π, length=N)
    zs = range(0, 1, length=N)
    f(z) = exp(z)
    z = []
    x = []#f.(z).*cos.(θ)
    y = []#f.(z).*sin.(θ)
    for zi in zs
        for θj in θ
            push!(z, zi)
            push!(x, f(zi) * cos(θj))
            push!(y, f(zi) * sin(θj))
        end
    end
    p = plot(dpi=600)
    plot!(p, x, y, z, label=nothing)
    x0, x1, y0, y1, z0, z1 = 0, 0, 0, 0, 0, 1
    plot!(p, [x0, x1], [y0, y1], [z0, z1], color="red", lw=0.5, label=nothing)
    x0, x1, y0, y1, z0, z1 = 0, f(1), 0, 0, 1, 1
    plot!(p, [x0, x1], [y0, y1], [z0, z1], color="red", lw=0.5, label=nothing)
    x0, x1, y0, y1, z0, z1 = 0, f(0), 0, 0, 0, 0
    plot!(p, [x0, x1], [y0, y1], [z0, z1], color="red", lw=0.5, label=nothing)
    plot!(p, f.(zs), zeros(N), zs, color="red", lw=1, label=nothing)

    savefig(p, "revolution.pdf")
end
plot_revolution()
function test04_MC()
    f(z) = exp(z)
    maxvalue = 3
    minvalue = -maxvalue

    Iexact = π * (exp(2) - 1) / 2
    Is = Float64[]
    nmax = 30
    for n = 1:nmax
        N = 2^n
        I = MC(f, minvalue, maxvalue, N=N)
        push!(Is, I)
        println("n=$n I = $I, ratio = $(abs(I - Iexact)/Iexact)")
    end
    plot(2 .^ (1:nmax), abs.(Is .- Iexact) / Iexact, xscale=:log10, yscale=:log10, label="error")
    plot!(2 .^ (1:nmax), (2 .^ (1:nmax)) .^ (-1 / 2), xscale=:log10, yscale=:log10, label=L"1/\sqrt{n}")
    savefig("MC.pdf")
end
test04_MC()