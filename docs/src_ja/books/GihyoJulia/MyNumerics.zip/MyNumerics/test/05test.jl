using Plots
function test05_lagrange()
    f(x) = 1 / (1 + 2x^3 + 4 * x^12)
    Ns = [8, 5, 4, 3]
    xmax = 3
    xmin = 0
    nmax = 100
    xs = range(xmin, xmax, length=nmax)
    yalldata = f.(xs)
    plot(xs, yalldata, label="original", lw=2, color="black")
    for N in Ns
        xdata = range(xmin, xmax, length=N)
        ydata = f.(xdata)
        fhokan = lagrange(xdata, ydata)
        ys = fhokan.(xs)
        plot!(xs, ys, label="order $(N-1)")
    end
    savefig("hokan.pdf")
end
test05_lagrange()
using Dierckx
function test05_spline()
    f(x) = 1 / (1 + 2x^3 + 4 * x^12)
    Ns = [8]
    xmax = 3
    xmin = 0
    nmax = 100
    xs = range(xmin, xmax, length=nmax)
    yalldata = f.(xs)
    plot(xs, yalldata, label="original", lw=2, color="black")
    for N in Ns
        xdata = range(xmin, xmax, length=N)
        println(xdata)
        ydata = f.(xdata)
        myspl = spline_func(xdata, ydata)
        myspl2 = Spline(xdata, ydata)
        #plot!(xdata,ydata,markershape=:circle,seriestype=:scatter,label=nothing)
        fhokan = lagrange(xdata, ydata)
        spl = Spline1D(xdata, ydata)
        yspl = spl.(xs)
        println(myspl(0.3), "\t", myspl2(0.3))
        @time yspl2 = myspl.(xs)
        @time yspl2 = myspl2.(xs)
        ys = fhokan.(xs)
        plot!(xs, yspl2, label="Spline: order $N points")
        plot!(xs, ys, label="Lagrange: order $N points")
    end
    savefig("hokan_spline.pdf")
end
test05_spline()
function test05_saisho()
    a = 3
    b = 0.5
    f(x) = a * x + b * cos(10 * x)
    xdata = range(-1, 1, length=15)
    ydata = f.(xdata)
    s = Saisho()
    for i = 1:length(xdata)
        add_data!(s, xdata[i], ydata[i])
        println("a,b = $(s.a[1]) $(s.a[2])")
    end
end
test05_saisho()
function test05_multiregression()
    f(x) = x^3 + 4 * x^2 + x + 10 + 0.5 * cos(10x)
    xdata = range(-1, 1, length=15)
    ydata = f.(xdata)

    functions = [x -> 1, x -> x, x -> x^2, x -> x^3]

    s = Multiregression(functions)
    for i = 1:length(xdata)
        add_data!(s, xdata[i], ydata[i])
        for i = 1:length(s.a)
            println("$i $(s.a[i])")
        end
    end
    ys = s.(xdata)
    plot(xdata, ydata, label="data", seriestype=:scatter)
    plot!(xdata, ys, label="line")
    savefig("multi.pdf")
end
test05_multiregression()

using Flux
function test05_NNfit()
    f(x) = x^3 + 4 * x^2 + x + 10 + 0.5 * cos(10x)
    xdata = range(-1, 1, length=15)
    ydata = f.(xdata)

    M = 10
    numtrain = 10000
    σ = relu
    model_relu = NNfit(xdata, ydata, M, numtrain, σ)
    σ(x) = tanh(x)
    model_tanh = NNfit(xdata, ydata, M, numtrain, σ)

    ys_relu = model_relu.(xdata)
    ys_tanh = model_tanh.(xdata)
    plot(xdata, ydata, label="data", seriestype=:scatter)
    plot!(xdata, ys_relu, label="relu")
    plot!(xdata, ys_tanh, label="tanh")
    savefig("NNfit_$(M).pdf")
end
test05_NNfit()
