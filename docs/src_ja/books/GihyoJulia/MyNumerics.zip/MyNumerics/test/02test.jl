function test02_chikuji()
    x0 = 0.1
    f(x) = cos(x) - x
    x = chikuji(f, x0)
    println(x, "\t", f(x))
end
test02_chikuji()
function test02_Steffensen()
    x0 = 0.4
    f(x) = 6 * x^2 - 0.5 - x
    x = steffensen(f, x0)
    println(x, "\t", f(x))
end
test02_Steffensen()
function test02_Newton()
    g(x) = cos(x) - x
    dg(x) = -sin(x) - 1
    x0 = 0.4
    x = newton(g, dg, x0)
    println(x, "\t", g(x))
end
test02_Newton()
function test02_multi_Newton()
    f(x) = [6 * x[1]^2 - 0.5 - x[2]
        cos(x[2]) - x[1]]
    df(x) = [12*x[1] -1
        -1 -sin(x[2])]
    x0 = [0.1, 0.2]
    x = newton(f, df, x0)
    println(x, "\t", f(x))
end
test02_multi_Newton()
function test02_bisection()
    g(x) = cos(x) - x
    a = -1
    b = 1
    x = bisection(g, a, b)
    println(x, "\t", g(x))
end
test02_bisection()
