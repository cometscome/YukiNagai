using Plots
function test06_euler()
    x0 = 0
    xend = 1
    h = 0.02
    y0 = 1.0
    f(x, y) = y - 2 * x
    yexact(x) = -exp(x) + 2 * x + 2

    xdata, ydata = euler(x0, xend, f, y0, h)
    plot(xdata, ydata, label="Euler: h = 0.02")
    xdata, ydata2 = euler(x0, xend, f, y0, 0.01)
    plot!(xdata, ydata2, label="Euler: h = 0.01")
    yexactdata = yexact.(xdata)
    plot!(xdata, yexactdata, label="Analytical")
    savefig("Euler.pdf")
end
test06_euler()

function test06_rk4()
    x0 = 0
    xend = 1
    h = 0.02
    y0 = 1.0
    f(x, y) = y - 2 * x
    yexact(x) = -exp(x) + 2 * x + 2

    xdata, ydata = rk4(x0, xend, f, y0, h)
    plot(xdata, ydata, label="Runge-Kutta: h = 0.02")
    xdata, ydata2 = rk4(x0, xend, f, y0, 0.01)
    plot!(xdata, ydata2, label="Runge-Kutta: h = 0.01")
    yexactdata = yexact.(xdata)
    plot!(xdata, yexactdata, label="Analytical")
    savefig("RK4.pdf")
end
test06_rk4()

function test06_addaptiveRungeKutta()
    x0 = -10
    xend = 10
    y0 = 0
    Δ(x) = tanh(x)
    f(x, y) = -2 * y - Δ(x) * y^2 + Δ(x)

    a, b, c, btilde = get_RKF_coeffs()
    q = 4
    xdata, ydata, hdata = adaptiveRungeKutta(x0, xend, f, y0, a, b, c, btilde, q, ϵ=1e-4)

    scatter(xdata, ydata, label="Runge-Kutta-Fehlberg")
    savefig("Riccati.pdf")
end
test06_addaptiveRungeKutta()
function test06_addaptiveRungeKutta_vector()
    a, b, c, btilde = get_RKF_coeffs()
    q = 4
    ξ0 = 1e-16
    ξend = 4
    θ0 = [1, 0]
    yexact_0(ξ) = 1 - ξ^2 / 6
    yexact_1(ξ) = sin(ξ) / ξ
    yexact_5(ξ) = (1 + ξ^2 / 3)^(-1 / 2)
    plot()
    ns = [0, 1, 5]
    for n in ns
        f1(ξ, θ) = θ[2]
        f2(ξ, θ) = -2 * θ[2] / ξ - θ[1]^n
        f = [f1, f2]
        xdata, ydata, hdata = adaptiveRungeKutta(ξ0, ξend, f, θ0, a, b, c, btilde, q, ϵ=1e-3)
        if n == 0
            yexactdata = yexact_0.(xdata)
        elseif n == 1
            yexactdata = yexact_1.(xdata)
        elseif n == 5
            yexactdata = yexact_5.(xdata)
        end
        scatter!(xdata, ydata[1], label="Runge-Kutta-Fehlberg n = $n", ylims=(0, 1.2))

        plot!(xdata, yexactdata, label="Analytical n = $n", ylims=(0, 1.2))
    end
    savefig("LK.pdf")
end
test06_addaptiveRungeKutta_vector()