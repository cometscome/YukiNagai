using MyNumerics
using Test
@testset "連立方程式" begin
    include("./01test.jl")
end
@testset "非線形方程式" begin
    include("./02test.jl")
end
@testset "固有値" begin
    include("./03test.jl")
end
@testset "数値微分" begin
    include("./04test.jl")
end
@testset "補間と近似" begin
    include("./05test.jl")
end
@testset "常微分方程式" begin
    include("./06test.jl")
end
@testset "偏微分方程式" begin
    include("./07test.jl")
end