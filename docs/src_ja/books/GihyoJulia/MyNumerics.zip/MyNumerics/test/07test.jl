using Plots
function test07_thermal_Euler()
    u_0(x) = ifelse(0.4 <= x <= 0.6, 1, 0) #1/(1+exp(-10*(x-1/2))) 
    Nx = 32
    Mt = 256 * 4
    x0 = 0
    x1 = 1
    t0 = 0
    t1 = 0.1
    xs = range(x0, x1, length=Nx)
    ts = range(t0, t1, length=Mt)
    u0 = u_0.(xs)
    println(u0)
    plot()
    κ = 1
    us = thermal_Euler(u0, xs, ts, κ)
    T = 2:64:Mt
    for Ts in T
        plot!(xs, us[:, Ts], label="")
    end
    plot!(xs, us[:, end], label="final")
    savefig("thermal_tdep.pdf")
end
test07_thermal_Euler()
function test07_crank_nicolson()
    u_0(x) = ifelse(0.4 <= x <= 0.6, 1, 0) #1/(1+exp(-10*(x-1/2))) 
    Nx = 32
    Mt = 256 * 4
    x0 = 0
    x1 = 1
    t0 = 0
    t1 = 0.1
    xs = range(x0, x1, length=Nx)
    ts = range(t0, t1, length=Mt)
    u0 = u_0.(xs)
    println(u0)
    plot()
    κ = 1
    us = crank_nicolson(u0, xs, ts, κ)
    T = 2:64:Mt
    for Ts in T
        plot!(xs, us[:, Ts], label="")
    end
    plot!(xs, us[:, end], label="final")
    savefig("crank_nicolson_tdep.pdf")
end
test07_crank_nicolson()
function test07_GaussSeidel()
    Nx = 10
    Ny = 10
    N = Nx * Ny
    L = 1
    x0 = 0.0
    x1 = L
    y0 = 0.0
    y1 = L
    xs = range(x0, x1, length=Nx)
    ys = range(y0, y1, length=Ny)
    h = xs[2] - xs[1]
    D = make_D(Nx, Ny)
    ρ(x, y) = sin(π * x / L)^2 * sin(π * y / L)
    vec_ρ = zeros(N)
    for ix = 1:Nx
        for iy = 1:Ny
            i = (iy - 1) * Nx + ix
            x = xs[ix]
            y = ys[iy]
            vec_ρ[i] = ρ(x, y)
        end
    end
    V = hanpuku_GaussSeidel(D / h^2, vec_ρ, printx=false)
    println("V = ", V)
    Vans = D / h^2 \ vec_ρ #Juliaの標準機能で解いてみます
    println("Vans = ", Vans)
    println(sum(abs, (V - Vans)))
end
test07_GaussSeidel()
function test07_cg()
    Nx = 10
    Ny = 10
    N = Nx * Ny
    L = 1
    x0 = 0.0
    x1 = L
    y0 = 0.0
    y1 = L
    xs = range(x0, x1, length=Nx)
    ys = range(y0, y1, length=Ny)
    h = xs[2] - xs[1]
    D = make_D(Nx, Ny)
    ρ(x, y) = sin(π * x / L)^2 * sin(π * y / L)
    vec_ρ = zeros(N)
    for ix = 1:Nx
        for iy = 1:Ny
            i = (iy - 1) * Nx + ix
            x = xs[ix]
            y = ys[iy]
            vec_ρ[i] = ρ(x, y)
        end
    end
    V = zero(vec_ρ)
    eps = 1e-12
    conjugate_gradient!(D / h^2, vec_ρ, V, eps)
    println("V = ", V)
    Vans = D / h^2 \ vec_ρ #Juliaの標準機能で解いてみます
    println("Vans = ", Vans)
    println(sum(abs, (V - Vans)))
end
test07_cg()
using LinearAlgebra
function test07_finiteelement()
    L = 1
    ρ(x) = sin(π * x / L)^2
    N = 100
    xs = range(0, L, length=N + 1)
    V = finiteelements(xs, ρ)
    plot(xs, V, labels="FEM")

    h = xs[2] - xs[1]
    D = make_D(N - 1) / h^2
    Dtmp = deepcopy(D)
    #println(D*h)
    ρvec = ρ.(xs)[begin+1:end-1]
    ρtmp = deepcopy(ρvec)
    LU!(Dtmp)
    xsabun = solve_withLU!(Dtmp, ρtmp)
    Vsabun = zero(xs)
    Vsabun[begin+1:end-1] .= xsabun

    plot!(xs, Vsabun, labels="FDM")
    savefig("FEM.pdf")

end
test07_finiteelement()