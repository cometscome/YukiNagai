function calc_l_i(i,x,xdata)
    bunbo = 1.0
    bunshi = 1.0
    n = length(xdata)
    for j=1:n
        if i == j
            continue
        end
        bunbo *= xdata[i] - xdata[j]
        bunshi *= x - xdata[j]
    end
    return bunshi/bunbo
end
function lagrange(xdata,ydata)
    @assert length(xdata) == length(ydata) "xとyの長さが異なっています。$(length(xdata))と$(length(ydata))です"
    function calc_y(x,xdata,ydata)
        y = 0.0
        n = length(xdata)
        for i=1:n
            l_i = calc_l_i(i,x,xdata)
            y += l_i*ydata[i]
        end
        return y
    end
    return x -> calc_y(x,xdata,ydata)
end
export lagrange

function make_spline_coefficients(xdata,ydata)
    @assert length(xdata) == length(ydata) "xとyの長さが異なっています。$(length(xdata))と$(length(ydata))です"
    N = length(xdata)
    smatrix = zeros(Float64,N,N)
    bvector = zeros(Float64,N)
    a = zeros(Float64,N-1)
    b = zeros(Float64,N-1)
    h1 = xdata[2]-xdata[1]
    smatrix[1,1] = 2*h1
    smatrix[1,2] = 1*h1
    bvector[1] = 3*(ydata[2]-ydata[1])
    hnm = xdata[N]-xdata[N-1]
    smatrix[N,N] = 1*hnm
    smatrix[N,N-1] = 2*hnm
    bvector[N] = 3*(ydata[N]-ydata[N-1])

    for i=2:N-1
        him = xdata[i] - xdata[i-1]
        hi = xdata[i+1]-xdata[i]
        smatrix[i,i-1] = hi
        smatrix[i,i] = 2*(him + hi)
        smatrix[i,i+1] = him
        bvector[i] = 3*(him/hi)*(ydata[i+1]-ydata[i]) + 3*(hi/him)*(ydata[i]-ydata[i-1])
    end
    smatrix_temp = deepcopy(smatrix)
    LU!(smatrix_temp)
    bvector_temp = deepcopy(bvector)
    c = solve_withLU!(smatrix_temp,bvector_temp)
    #c = smatrix \ bvector #連立方程式を解く
    hi = xdata[1+1]-xdata[1]
    a[1] = (c[1+1]-c[1] - 2*b[1]*hi)/(3*hi^2)
    for i=2:N-2
        hi = xdata[i+1]-xdata[i]
        b[i] = (3*(ydata[i+1]-ydata[i])-hi*(c[i+1]+2*c[i]))/hi^2
        a[i] = (c[i+1]-c[i] - 2*b[i]*hi)/(3*hi^2)
    end
    hi = xdata[N]-xdata[N-1]
    a[N-1] = (c[N]-c[N-1] - 2*b[N-1]*hi)/(3*hi^2)
    return a,b,c
end
function spline_interpolation(x,a,b,c,xdata,ydata)
    @assert xdata[begin] <= x <= xdata[end] "補間の外の値です"
    i = findfirst(xi -> xi >= x,xdata) -1
    i = ifelse(i==0,1,i)
    hx = x-xdata[i]
    y = a[i]*hx^3 + b[i]*hx^2 + c[i]*hx + ydata[i]
    return y
end
function spline_func(xdata,ydata)
    a,b,c = make_spline_coefficients(xdata,ydata)
    return x -> spline_interpolation(x,a,b,c,xdata,ydata)
end
export spline_func
struct Spline
    xdata::Vector{Float64}
    ydata::Vector{Float64}
    a::Vector{Float64}
    b::Vector{Float64}
    c::Vector{Float64}
    function Spline(xdata,ydata)
        a,b,c = make_spline_coefficients(xdata,ydata)
        return new(xdata,ydata,a,b,c)
    end
end
function (s::Spline)(x)
    spline_interpolation(x,s.a,s.b,s.c,s.xdata,s.ydata)
end
export Spline
function make_X(xdata)
    n = length(xdata)
    X = zeros(Float64,n,2)
    for i=1:n
        X[i,1] = xdata[i]
        X[i,2] = 1
    end
    return X
end
function saisho(xdata,ydata)
    X = make_X(xdata)
    a = (X'*X) \ (X'*ydata)
    println(a)
    return x -> a[1]*x + a[2]
end

function update_XtX_Xty!(XtX,Xty,x,y)
    XtX[1,1] += x^2
    XtX[1,2] += x
    XtX[2,1] += x
    XtX[2,2] += 1
    Xty[1] += x*y
    Xty[2] += y  
end

struct Saisho
    xdata::Vector{Float64}
    ydata::Vector{Float64}
    a::Vector{Float64}
    XtX::Matrix{Float64}
    Xty::Vector{Float64}

    function Saisho()
        xdata = Vector{Float64}[]
        ydata = Vector{Float64}[]
        a = zeros(Float64,2)
        XtX = zeros(Float64,2,2)
        Xty = zeros(Float64,2)
        return new(xdata,ydata,a,XtX,Xty)
    end
end
function add_data!(s::Saisho,x,y)
    push!(s.xdata,x)
    push!(s.ydata,y)
    update_XtX_Xty!(s.XtX,s.Xty,x,y)
    if length(s.xdata) > 2
        s.a .= s.XtX \ s.Xty
    end
end
export add_data!
export Saisho
function update_XtX_Xty!(XtX,Xty,x,y,functions)
    n = length(functions)
    for i=1:n
        for j=1:n
            XtX[j,i] += functions[i](x)*functions[j](x)
        end
        Xty[i] += functions[i](x)*y
    end
end
struct Multiregression
    xdata::Vector{Float64}
    ydata::Vector{Float64}
    a::Vector{Float64}
    XtX::Matrix{Float64}
    Xty::Vector{Float64}
    functions::Vector{Function}

    function Multiregression(functions)
        xdata = Vector{Float64}[]
        ydata = Vector{Float64}[]
        numfunc = length(functions)
        a = zeros(Float64,numfunc)
        XtX = zeros(Float64,numfunc,numfunc)
        Xty = zeros(Float64,numfunc)
        return new(xdata,ydata,a,XtX,Xty,functions)
    end
end
function add_data!(s::Multiregression,x,y)
    push!(s.xdata,x)
    push!(s.ydata,y)
    update_XtX_Xty!(s.XtX,s.Xty,x,y,s.functions)
    if length(s.xdata) > 2
        s.a .= s.XtX \ s.Xty
    end
end

function (s::Multiregression)(x)
    return sum([s.a[i]*s.functions[i](x) for i=1:length(s.functions)])
end
export Multiregression

using Flux
function NNfit(xdata,ydata,M,numtrain,σ)
    model = Chain(x -> [x],Dense(1,M,σ),Dense(M,1),x -> x[1])
    opt = Flux.setup(Adam(), model)
    numdata = length(xdata)
    for i=1:numtrain
        lossvalue = 0.0
        for i=1:numdata
            x = xdata[i]
            y = ydata[i]     
            loss, grads = Flux.withgradient(model) do m
                y_hat = m(x)
                Flux.mse(y_hat, y)
            end
            Flux.update!(opt, model, grads[1])
            lossvalue += loss
        end
        lossvalue /= numdata
        if i % 100 == 0
            println("$i $lossvalue")
        end
    end
    return model
end
export NNfit