using SparseArrays
function thermal_Euler(u0,xs,ts,κ)
    Nx = length(xs)
    Mt = length(ts)
    us = zeros(Nx,Mt)

    h = xs[2]-xs[1]
    Δt = ts[2]-ts[1]
    D = spzeros(Nx,Nx)
    a = κ*Δt/h^2
    for i=1:Nx
        j = i+1
        if 1 <= j <= Nx
            D[i,j] = a
        end
        j = i-1
        if 1 <= j <= Nx
            D[i,j] = a
        end
        j= i 
        D[i,j] = -2a
    end

    us[:,1] .= u0
    for i=2:Mt
        us[:,i] = us[:,i-1] + D*us[:,i-1]
    end
    return us
end
export thermal_Euler
function crank_nicolson(u0,xs,ts,κ)
    Nx = length(xs)
    Mt = length(ts)
    us = zeros(Nx,Mt)

    h = xs[2]-xs[1]
    Δt = ts[2]-ts[1]
    D = spzeros(Nx,Nx)
    a = κ*Δt/h^2
    for i=1:Nx
        j = i+1
        if 1 <= j <= Nx
            D[i,j] = a
        end
        j = i-1
        if 1 <= j <= Nx
            D[i,j] = a
        end
        j= i 
        D[i,j] = -2a
    end
    A = sparse(I, Nx,Nx) - D/2
    B = sparse(I, Nx,Nx) + D/2

    us[:,1] .= u0
    for i=2:Mt
        us[:,i] = hanpuku_GaussSeidel(A,B*us[:,i-1],printx=false)
    end
    return us
end
export crank_nicolson
using SparseArrays
function make_D(Nx,Ny)
    N = Nx*Ny
    D = spzeros(N,N)
    ds = [(1,0),(-1,0),(0,1),(0,-1)]
    for ix=1:Nx
        for iy=1:Ny
            i = (iy-1)*Nx + ix
            for d in ds
                jx = ix + d[1]
                jy = iy + d[2]
                j = (jy-1)*Nx + jx
                if 1 <= jx <= Nx && 1 <= jy <= Ny
                    D[i,j] = 1
                end
            end
            D[i,i] = -4
        end
    end
    return D
end
export make_D

function make_Kij(xs)
    N = length(xs)-1
    K = spzeros(N-1,N-1)
    for i=1:N-1
        j = i
        K[i,i] += -1/(xs[i+1]-xs[i-1+1])
        if i < N
            K[i,i] += -1/(xs[i+1+1]-xs[i+1])
        end

        if i < N-1
            j = i+1
            K[i,j] += 1/(xs[i+1+1]-xs[i+1])
        end

        j = i-1
        if i > 1
            K[i,j] += 1/(xs[i+1]-xs[i-1+1])
        end
    end
    return K
end

function make_fi(xs,ρ)
    N = length(xs)-1
    f = zeros(N-1)
    for i=1:N-1
        xm = (xs[i+1]+xs[i-1+1])/2
        f[i] += ρ(xm)*(xs[i+1]-xs[i-1+1])/2
        if i < N
            xp = (xs[i+1+1]+xs[i+1])/2
            f[i] += ρ(xp)*(xs[i+1+1]-xs[i+1])/2
        end
    end
    return f
end

function make_D(N)
    D = spzeros(N,N)
    ds = (-1,1)
    for i=1:N
        for d in ds
            j = i +d
            if 1 <= j <= N
                D[i,j] += 1
            end
        end
        D[i,i] += -2
    end
    return D
end

function finiteelements(xs,ρ)
    K = make_Kij(xs)
    f = make_fi(xs,ρ)
    LU!(K)
    x = solve_withLU!(K,f)
    V = zero(xs)
    V[begin+1:end-1] .= x 
    return V
end
export finiteelements