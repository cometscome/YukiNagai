function euler(x0,xend,f,y0,h)
    x = x0
    y = y0
    xdata = []
    ydata = []
    push!(ydata,y0)
    push!(xdata,x0)
    while x <= xend
        x += h
        y += h*f(x,y)         
        push!(ydata,y)
        push!(xdata,x)
    end
    return xdata,ydata
end
export euler

function rk4(x0,xend,f,y0,h)
    x = x0
    y = y0
    xdata = []
    ydata = []
    push!(ydata,y0)
    push!(xdata,x0)
    while x <= xend
        k1 = f(x,y)
        k2 = f(x+h/2,y+h*k1/2)
        k3 = f(x + h/2,y+h*k2/2)
        k4 = f(x + h,y + h*k3)
        y += (h/6)*(k1+2k2+2k3+k4)
        x += h
        push!(ydata,y)
        push!(xdata,x)
    end
    return xdata,ydata
end
export rk4
function runge_kutta(x0,xend,f,y0,h,a,b,c)
    x = x0
    y = y0
    xdata = []
    ydata = []
    push!(ydata,y0)
    push!(xdata,x0)
    s = length(c)
    k = zeros(s)
    while x <= xend
        k[1] = f(x,y)
        for i=2:s
            yp = y
            for j=1:i-1
                yp += h*a[i,j]*k[j]
            end
            k[i] = f(x + c[i]*h,yp)
        end

        for i=1:s
            y += h*b[i]*k[i]
        end
        x += h
        push!(ydata,y)
        push!(xdata,x)
    end
    return xdata,ydata
end
export runge_kutta
function get_RKF_coeffs()
    a = [
            0          0           0           0        0     0
            1/4          0           0           0        0     0
            3/32        9/32         0           0        0     0
        1932/2197  -7200/2197   7296/2197      0        0     0
        439/216       -8       3680/513   -845/4104     0     0
        -8/27          2      -3544/2565   1859/4104  -11/40  0
    ]
    b =      [16/135,0,6656/12825,28561/56430,-9/50,2/55]
    btilde = [25/216,0,1408/2565,2197/4104,-1/5,0]
    c = [0,1/4,3/8,12/13,1,1/2]
    return a,b,c,btilde
end
export get_RKF_coeffs
function adaptiveRungeKutta(x0,xend,f,y0,a,b,c,btilde,q;h0=0.01,α=0.9,ϵ=1e-3)
    h = h0
    x = x0
    y = y0
    xdata = []
    ydata = []
    hdata = []
    push!(ydata,y0)
    push!(xdata,x0)
    push!(hdata,h)
    s = length(c)
    k = zeros(s)
    while x <= xend
        k[1] = f(x,y)
        for i=2:s
            yp = y
            for j=1:i-1
                yp += h*a[i,j]*k[j]
            end
            k[i] = f(x + c[i]*h,yp)
        end
        dy = 0.0
        for i=1:s
            y += h*b[i]*k[i]
            dy += h*abs((b[i]-btilde[i])*k[i])
        end
        x += h
        h = α*h*(ϵ/dy)^(1/q)
        push!(ydata,y)
        push!(xdata,x)
        push!(hdata,h)
    end
    return xdata,ydata,hdata
end
export adaptiveRungeKutta
function adaptiveRungeKutta(x0,xend,f,y0::AbstractVector{T},a,b,c,btilde,q;h0=0.01,α=0.9,ϵ=1e-3) where T
    numeq = length(y0)
    h = h0
    x = x0
    y = zeros(numeq)
    y .= y0
    xdata = []
    ydata = Vector{Vector{Float64}}(undef,numeq)
    for n=1:numeq
        ydata[n] = []
    end
    hdata = []
    for n=1:numeq
        push!(ydata[n],y0[n])
    end
    push!(xdata,x0)
    push!(hdata,h)
    s = length(c)
    k = zeros(numeq,s)
    yp = zeros(numeq)
    dy = zeros(numeq)
    while x <= xend
        for n=1:numeq
            k[n,1] = f[n](x,y)
        end
        for i=2:s
            yp .= y
            for j=1:i-1
                for n=1:numeq
                    yp[n] += h*a[i,j]*k[n,j]
                end
            end
            for n=1:numeq
                k[n,i] = f[n](x + c[i]*h,yp)
            end
        end
        dy .= 0.0
        for i=1:s
            for n=1:numeq
                y[n] += h*b[i]*k[n,i]
                dy[n] += h*abs((b[i]-btilde[i])*k[n,i])
            end
        end
        x += h
        dymax = max(dy...)

        h = α*h*(ϵ/dymax)^(1/q)
        for n=1:numeq
            push!(ydata[n],y[n])
        end
        push!(xdata,x)
        push!(hdata,h)
    end
    return xdata,ydata,hdata
end   