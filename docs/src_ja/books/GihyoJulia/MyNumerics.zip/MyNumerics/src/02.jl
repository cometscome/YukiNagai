function chikuji(f,x0;eps = 1e-10,maxiteration = 1000)
    g(x) = f(x) + x
    x = g(x0)
    xold = x
    for i=1:maxiteration
        x = g(xold)
        r = abs(x-xold)/abs(x) 
        if r < eps
            println("converged. $i-th eps: $r")
            return x
        end
        xold = x
    end
    error("not converged $(abs(x-xold)/abs(x) )")
end
export chikuji
function steffensen(f,x0;eps = 1e-10,maxiteration = 1000)
    g(x) = f(x) + x
    x = x0
    xold = x0
    xoldold = xold
    for i=1:maxiteration

        x = g(xold)
        r = abs(x-xold)/abs(x) 
        if r < eps
            println("converged. $i-th eps: $r")
            return x
        end
        if i % 2 == 0
            x = xoldold - (xoldold - xold)^2/(xoldold - 2*xold + x)
        end
        
        xoldold = xold
        xold = x
    end
    error("not converged $(abs(x-xold)/abs(x) )")
end
export steffensen
function newton(f,df,x0;eps = 1e-10,maxiteration = 1000)
    x = x0
    for i=1:maxiteration
        fx = f(x)
        r = abs(fx)
        if r < eps
            println("converged. $i-th eps: $r")
            return x
        end
        x -= fx/df(x)
    end
    error("not converged $(abs(x-xold)/abs(x) )")
end
function newton(f,df,x0::T;eps = 1e-10,maxiteration = 1000) where T <: AbstractVector
    x = copy(x0)
    for i=1:maxiteration
        fx = f(x)
        r = sum(abs.(fx))
        if r < eps
            println("converged. $i-th eps: $r")
            return x
        end
        dftemp = df(x)
        LU!(dftemp)
        x -= solve_withLU!(dftemp,fx)
        #x -= df(x) \ fx #Julia標準機能で解く場合
    end
    error("not converged $(abs(x-xold)/abs(x) )")
end
export newton
function bisection(f,a,b;eps = 1e-10,maxiteration = 1000)
    xa = a
    xb = b
    fa = f(xa)
    fb = f(xb)
    @assert fa*fb < 0 "f(a)f(b) < 0 is not satisfied!"
    for i=1:maxiteration
        xc = (xa + xb)/2
        fc = f(xc)
        if fa*fc < 0
            xb = xc
            fb = fc
        else
            xa = xc
            fa = fc
        end
        r = abs(fc)
        if r < eps
            println("converged. $i-th eps: $r")
            return xc
        end
    end
end
export bisection