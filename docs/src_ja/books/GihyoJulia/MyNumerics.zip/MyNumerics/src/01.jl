function hanpuku_Jacobi(A,b;eps = 1e-7,printx=true)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    x = zeros(Float64,n) #解の候補のベクトル。ここでは実数を仮定。
    x_temp = zero(x) #計算用の一時ベクトル。適宜更新される
    imax = 1000 #繰り返し代入の最大の数
    converged = false
    for i =1:imax
        err = 0.0 #誤差
        for j=1:n
            x_temp[j] = b[j] #まずbの値を足しておく
            for k=1:n
                if k==j
                    continue #対角の場合は計算しないのでスキップ
                end
                x_temp[j] -= A[j,k]*x[k] 
            end
            x_temp[j] /= A[j,j] #対角要素で割る
            err += abs(x[j]-x_temp[j]) #j番めの要素の誤差を足す
        end
        if err < eps
            converged = true
            break
        else
            x .= x_temp #解の候補を更新
        end
        if printx
            println("$i ",x)
        end
    end
    if  converged
        println("収束しました")
    else
        println("収束しませんでした")
    end
    return x
end
export hanpuku_Jacobi

function hanpuku_GaussSeidel(A,b;eps = 1e-7,printx=true)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    x = zeros(Float64,n) #解の候補のベクトル。ここでは実数を仮定。
    imax = 1000 #繰り返し代入の最大の数
    converged = false
    for i =1:imax
        err = 0.0 #誤差
        for j=1:n
            xjold = x[j] #誤差の評価のため前の値を保持しておく
            x[j] = b[j] #まずbの値を足しておく
            for k=1:n
                if k==j
                    continue #対角の場合は計算しないのでスキップ
                end
                x[j] -= A[j,k]*x[k] 
            end
            x[j] /= A[j,j] #対角要素で割る
            err += abs(xjold-x[j]) #j番めの要素の誤差を足す
        end
        if err < eps
            converged = true
            break
        end
        if printx
            println("$i ",x)
        end
    end
    if  converged
        println("収束しました")
    else
        println("収束しませんでした")
    end
    return x
end
export hanpuku_GaussSeidel

function syokyo(A,b,i)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    Ap = zeros(Float64,n,n)
    bp = zeros(Float64,n)
    
    for k=1:n
        a = A[k,i]/A[i,i]
        for j=1:n
            if k==i #i番めの方程式からは引かない
                Ap[k,j] = A[k,j] 
            else
                Ap[k,j] = A[k,j] - A[i,j]*a
            end
        end
        bp[k] = b[k] - b[i]*a
    end
    return Ap,bp
end
export syokyo

function syokyo_fast(A,b,i)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    Ap = zeros(Float64,n,n)
    bp = zeros(Float64,n)
    Ap .= A
    bp .= b
    
    @inbounds for k=1:n
        a = A[k,i]/A[i,i]
        bp[k] -= b[i]*a
        if k != i
            for j=1:n
                Ap[k,j] -= A[i,j]*a
            end
        end
    end
    return Ap,bp
end
export syokyo_fast

#=
function syokyo_fast(A,b,i)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    Ap = zeros(Float64,n,n)
    bp = zeros(Float64,n)

    atemp = zeros(Float64,n)
    for k=1:n
        atemp[k] = A[k,i]/A[i,i]
        a = atemp[k]
        bp[k] = b[k] - b[i]*a
    end
    
    for j=1:n
        Aij = A[i,j]
        for k=1:n
            #a = A[k,i]/A[i,i]
            a = atemp[k]
            if k==i #i番めの方程式からは引かない
                Ap[k,j] = A[k,j] 
            else
                Ap[k,j] = A[k,j] - Aij*a
            end
        end
    end
    return Ap,bp
end
export syokyo_fast
=#

function gauss!(A,b)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    for i=1:n #i番目の方程式
        for k=(i+1):n #iよりも下にある方程式。i番目の方程式を使って消す
            a = A[k,i]/A[i,i] #k番目の方程式のi個目の変数を消すため。
            for j=i:n
                A[k,j] -=  A[i,j]*a #j=iの時、係数を消してくれている
            end
            b[k] -=  b[i]*a
        end
    end
end
export gauss!

function LU!(A)
    n,m = size(A)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    for i=1:n
        for k=(i+1):n
            a = A[k,i]/A[i,i]
            for j=i:n
                A[k,j] -=  A[i,j]*a
            end
            A[k,i] = a #bを計算する代わりに格納する
        end
    end
end
export LU!

function solve_withLU!(A,b)
    n,m = size(A)
    x = zeros(Float64,n)
    @assert n==m "正方行列である必要があります。$n x $m 行列です。"
    for i=1:n
        for k=(i+1):n
            a = A[k,i]
            b[k] -=  b[i]*a
        end
    end
    x[n] = b[n]/A[n,n]
    for i=(n-1):-1:1
        a = b[i]
        for j=(i+1):n
            a -= A[i,j]*x[j]
        end
        x[i] = a/A[i,i]
    end
    return x
end
export solve_withLU!
using LinearAlgebra
function gradient_descent!(A,b,x,eps)
    p = b- A*x 
    rnorm = norm(p)
    count = 0
    while rnorm > eps
        count += 1
        p = b - A*x
        rnorm = norm(p)
        Ap = A*p
        α = dot(p,p)/dot(Ap,p)
        x .+= α*p 
        println("$count $rnorm")
    end
end
export gradient_descent!

function conjugate_gradient!(A,b,x,eps)
    r = deepcopy(b)
    mul!(r, A, x, -1, 1) #r = -1*A*x + 1*r -> b-A*x
    p = deepcopy(r)
    Ap = zero(x)
    rnorm = norm(r)
    count = 0
    while rnorm > eps
        count += 1
        mul!(Ap,A,p) #Ap = A*p
        pAp = dot(p,Ap)
        α = dot(p,r)/pAp
        axpy!(α,p,x) #x = x + α*p 
        axpy!(-α,Ap,r) #r = r - α*Ap

        rnorm = norm(r)
        β = -dot(r,Ap)/pAp

        axpby!(1,r,β,p) #p = 1*r + β*p
    end
    println("$count $rnorm")
end
export conjugate_gradient!