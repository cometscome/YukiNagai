function kubun(f,a,b;N=100)
    dx = (b-a)/N
    I = 0.0
    for i=0:N-1
        x = i*dx + a
        I += f(x)*dx
    end
    return I
end
export kubun

function daikei(f,a,b;N=100)
    dx = (b-a)/N
    I = (f(a) + f(b))*dx/2
    for i=1:N-1
        x = i*dx + a
        I += f(x)*dx
    end
    return I
end
export daikei
function simpson(f,a,b;N=100)
    dx = (b-a)/N
    I = f(a) + f(b)
    I += 4*f(b-dx)
    for i=1:2:N-3
        x = i*dx + a
        I += 4*f(x) + 2*f(x+dx)
    end
    return I*dx/3
end
export simpson
function legendre_polynomial(x,N)
    if N==0
        Pn = 1.0
    elseif N==1
        Pn = x
    else
        Pn_old = 1.0
        Pn = x
        for n=2:N
            Pn_new = (2n-1)*x*Pn - (n-1)*Pn_old
            Pn_new /= n
            Pn_old = Pn
            Pn = Pn_new
        end
    end
    return Pn
end
export legendre_polynomial
function functionzeros(N)
    fNm(x) = legendre_polynomial(x,N-1)
    fN(x) = legendre_polynomial(x,N)
    df(x) = N*(fNm(x) - x*fN(x))/(1-x^2)
    xks = Float64[]
    for k=1:N
        x0 = sin((N+1-2k)*π/(2N+1))
        xk = newton(fN,df,x0)
        push!(xks,xk)
    end
    return xks
end
export functionzeros
function legendre_Gauss(f,a,b,lzeros;N=10)
    x(t) = t*(b-a)/2 + (a+b)/2 #[-1,1]への変数変換
    dxdt = (b-a)/2
    I = 0.0
    for k=1:N
        tk = lzeros[k] #ルジャンドル多項式のゼロ点
        Pnm = legendre_polynomial(tk,N-1) #P_{n-1}(x_k)
        Wk = 2(1-tk^2)/(N*Pnm)^2
        I += Wk*f(x(tk))
    end
    return I*dxdt
end
export legendre_Gauss
function MC(f,minvalue,maxvalue;N=10000)
    I = 0.0
    cellvolume = (maxvalue-minvalue)^3
    for i=1:N
        x = (maxvalue-minvalue)*rand() + minvalue
        y = (maxvalue-minvalue)*rand() + minvalue
        z = (maxvalue-minvalue)*rand() + minvalue
        r = sqrt(x^2+y^2)

        rf = f(z) 
        if r < rf
            if 0 <= z <= 1
                I += 1.0
            end
        end 
    end
    return cellvolume*I/N
end
export MC