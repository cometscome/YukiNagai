function power_method(A,x0;eps = 1e-8,maxiteration = 1000)
    n,m = size(A)
    @assert n == length(x0) "size mismatch!"
    x = copy(x0)
    xold = copy(x0)
    r = 0.0
    for i=1:maxiteration
        mul!(x,A,xold) #x = A*xoldでも可。
        λ = dot(x,x)/dot(x,xold)
        r = norm(x - λ*xold)/norm(xold)
        x ./=  norm(x)
        println("$i $r $(norm(x))")
        if r < eps
            println("converged. residual: $r")
            return λ,x
        end
        xold,x = x,xold #xold .= xでも可
    end
    error("not converged! residual: $r")
end
export power_method

function inverse_power_method(A,x0;eps = 1e-8,maxiteration = 1000)
    n,m = size(A)
    @assert n == length(x0) "size mismatch!"
    x = copy(x0)
    xold = copy(x0)
    r = 0.0
    for i=1:maxiteration
        x = A \ xold #標準機能を使う場合
        λ = dot(x,x)/dot(x,xold)
        r = norm(x - λ*xold)/norm(xold)
        x ./=  norm(x)
        println("$i $r $(norm(x))")
        if r < eps
            println("converged. residual: $r")
            return 1/λ,x
        end
        xold,x = x,xold
    end
    error("not converged! residual: $r")
end
function inverse_power_method_LU(A,x0;eps = 1e-8,maxiteration = 1000)
    n,m = size(A)
    @assert n == length(x0) "size mismatch!"
    x = copy(x0)
    xold = copy(x0)
    ALU = zeros(n,m)
    ALU .= A
    LU!(ALU)
    xtmp = zero(xold)
    #luA = lu(A)　# 標準機能を使うなら
    r = 0.0
    for i=1:maxiteration
        xtmp .= xold
        x = solve_withLU!(ALU,xtmp)
        #x = luA \ xold # 標準機能を使うなら
        λ = dot(x,x)/dot(x,xold)
        r = norm(x - λ*xold)/norm(xold)
        x ./=  norm(x)
        println("$i $r $(norm(x))")
        if r < eps
            println("converged. residual: $r")
            return 1/λ,x
        end
        xold,x = x,xold
    end
    error("not converged! residual: $r")
end
export inverse_power_method,inverse_power_method_LU
function make_U(A,p,q)
    n,m = size(A)
    @assert n == m "A should be a square matrix"
    U = zeros(n,m)

    App = A[p,p]
    Aqq = A[q,q]
    Apq = A[p,q]
    if App != Aqq
        θ = atan(2Apq/(Aqq-App))/2
    else
        θ = π/4
    end
    for i=1:n
        U[i,i] = 1
    end
    U[p,p] = cos(θ)
    U[q,q] = cos(θ)
    U[p,q] = sin(θ)
    U[q,p] = -sin(θ)
    return U
end
export make_U
function get_U(A)
    n,m = size(A)
    p=0
    q=0
    v=0
    for i=1:n
        for j=i+1:n
            if abs(A[i,j]) > v
                p = i
                q = j
                v = abs(A[i,j])
            end
        end
    end
    U = make_U(A,p,q)
    return U,v
end
function eigen_Jacobi(A;eps = 1e-8,maxiteration = 1000)
    U,maxval =get_U(A)
    Ui = copy(U)
    Ai = Ui'*A*Ui
    println("0 $maxval")
    display(Ai)
    println("\t")

    for i=1:maxiteration
        Ui,maxval =get_U(Ai)
        Ai = Ui'*Ai*Ui

        U = U*Ui
        
        println("$i $maxval")
        display(Ai)
        println("\t")
        if maxval < eps
            return Ai,U
        end
    end
    error("not converged! residual: $maxval ")
end
export eigen_Jacobi

function householder(A)
    N,M = size(A)
    A1 = deepcopy(A)
    α = zeros(N) #対角要素
    β = zeros(N) #非対角要素
    u = zero(A) #ハウスホルダー変換用
    p = zeros(N)
    q = zeros(N)
    for i=1:N-2
        s = 0.0
        for j=i+1:N
            u[j,i] = A1[j,i]
            s += u[j,i]^2
        end
        s = sqrt(s)
        α[i] = A1[i,i] 
        β[i] = ifelse(A[i+1,i] < 0,s,-s)
        u[i+1,i] -= β[i]
        c = sqrt(-2*β[i]*u[i+1,i])
        u[:,i] ./= c
        for j=i:N #pの計算
            p[j] = 0
            for k=i:N
                p[j] += A1[j,k]*u[k,i]
            end
        end
        up = 0.0
        for j=i:N #u^T pの計算
            up += u[j,i]*p[j]
        end
        for j=i:N #qの計算
            q[j]= 2*(p[j]- up*u[j,i])
        end
        for j=i:N
            for k=i:N
                A1[j,k] += - u[j,i]*q[k] - q[j]*u[k,i]  
            end
        end
        println("i = $i")
        display(A1)
        println("\t")
    end
    α[N-1] = A1[N-1,N-1]
    α[N] = A1[N,N]
    β[N-1] = A1[N,N-1]

    return α,β,u
end
export householder

function householder_matmul(α,β,x)
    N = length(α)
    xout = zero(x)
    xout[1] += α[1]*x[1] + β[1]*x[2]
    for i=2:N-1
        xout[i] += + β[i-1]*x[i-1] + α[i]*x[i] + β[i]*x[i+1]
    end
    xout[N] += β[N-1]*x[N-1] + α[N]*x[N] 
    return xout
end
export householder_matmul

function householder_backtransform(u,x)
    N,M = size(u)
    xout = deepcopy(x)
    for i=N-2:-1:1
        # R^{(i)} x= x - 2 u u^T x
        ux = 0.0
        for k=i:N
            ux += u[k,i]*xout[k]
        end
        for k=i:N
            xout[k] += -2*ux*u[k,i]
        end
    end
    return xout
end
export householder_backtransform


function count_Nlambda(α,β,λ;ϵ=1e-8)
    N = length(α)
    Ncount = 0
    gi = λ-α[1]
    Ncount += ifelse(gi < 0,1,0)
    for i=2:N
        if gi == 0
            gi = ϵ
        end
        gi = λ-α[i]-β[i-1]^2/gi
        Ncount += ifelse(gi < 0,1,0)
    end
    return Ncount 
end

function trigonal_matrix_bisection(α,β;eps = 1e-8,maxiteration = 1000)
    N = length(α)
    λmax = α[1]+abs(β[1])
    λmin = α[1]-abs(β[1])
    for i=2:N-1
        p = α[i]+abs(β[i-1])+abs(β[i])
        λmax = ifelse(p > λmax,p,λmax)
        p = α[i]-abs(β[i-1])-abs(β[i])
        λmin = ifelse(p < λmin,p,λmin)
    end
    p = α[N]+abs(β[N-1])
    λmax = ifelse(p > λmax,p,λmax)
    p = α[N]-abs(β[N-1])
    λmin = ifelse(p < λmin,p,λmin)
    a = λmin
    b = λmax
    println("max and min: $b $a")
    λs = Float64[]
    for k=1:N
        λk = trigonal_matrix_bisection_k(α,β,a,b,k;eps,maxiteration)
        b = λk
        push!(λs,λk)
    end
    return λs
end

function trigonal_matrix_bisection_k(α,β,a0,b0,k;eps = 1e-8,maxiteration = 1000)
    a = a0
    b = b0
    for i=1:maxiteration
        c = (a + b)/2
        Nc = count_Nlambda(α,β,c)
        if Nc < k
            b = c
        else
            a = c
        end
        r = abs(a-b)
        if r < eps
            println("converged. $i-th eps: $r")
            return c
        end
    end
end
export trigonal_matrix_bisection