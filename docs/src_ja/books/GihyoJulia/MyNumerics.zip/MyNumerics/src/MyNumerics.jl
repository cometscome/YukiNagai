module MyNumerics
include("./01.jl")#連立方程式
include("./02.jl")#非線形方程式
include("./03.jl")#固有値
include("./04.jl")#数値微分
include("./05.jl")#補間と近似
include("./06.jl")#常微分方程式
include("./07.jl")#偏微分方程式
function hellomypackage()
    println("こんにちは！")
end
end