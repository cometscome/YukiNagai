# MyNumerics

[![Build Status](https://github.com/hogehoge/MyNumerics.jl/actions/workflows/CI.yml/badge.svg?branch=main)](https://github.com/hogehoge/MyNumerics.jl/actions/workflows/CI.yml?query=branch%3Amain)
